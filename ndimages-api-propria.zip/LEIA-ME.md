# API própria do NDImages

Esta API executa o recorte em CPU, sem chamar um serviço de inferência externo.
O modelo U²-NetP já está incluído. O site no GitHub Pages usa o recorte aprimorado
no dispositivo e não precisa deste servidor para funcionar.

## Executar

1. Instale Node 24 LTS e pnpm 11.25.0.
2. Extraia o ZIP e execute pnpm install --frozen-lockfile --prod.
3. Copie .env.example para .env, ative NDIMAGES_BG_ENABLED=true
   e mantenha NDIMAGES_BG_ALLOWED_ORIGIN=https://contadsfreires.github.io.
4. Execute pnpm start. Confira GET /api/background/status na porta 4173.
5. Hospede este processo em um servidor Node com HTTPS. Para usar Docker:
   docker build -f Dockerfile.background -t ndimages-background .
   e docker run --rm -p 8080:8080 ndimages-background.
6. No código completo do frontend, configure SITE_BACKGROUND_API_ORIGIN
   com a origem HTTPS pública da API, compile e publique o site novamente.
   O GitHub Pages não executa este servidor Node.

## Qualidade maior com ORMBG

Os testes reais também validaram ORMBG quantizado em 1024 × 1024. Baixe os pesos
Apache-2.0 deste endereço fixo:
https://huggingface.co/onnx-community/ormbg-ONNX/resolve/034e2d884afbab897e10e78fc5bb566b29533fd6/onnx/model_quantized.onnx

O arquivo tem 44.315.205 bytes e SHA-256
ffbcae62a7b675d616e64cb392ee028786c4cf74f83596590fba13733ef00171.

Defina NDIMAGES_BG_MODEL_KIND=ormbg e NDIMAGES_BG_MODEL com o caminho
absoluto desse arquivo. Para Docker, monte o arquivo no contêiner e configure
essas duas variáveis no ambiente. Os pesos ORMBG não estão incluídos neste ZIP.

## Contrato e limites

POST /api/background/remove aceita o corpo binário JPG, PNG ou WebP com seu
Content-Type. Retorna PNG no tamanho original. Não salva as fotos em disco.
Aceita até 16 MB, 16 milhões de pixels, 8.192 pixels por lado; uma imagem por vez.
O limite padrão é de 30 requisições por IP/hora, mantido em memória por instância.
Atrás de proxy, configure o limite na infraestrutura para não compartilhar a cota.
Restrinja a origem no ambiente. Não é necessário token de um provedor de IA.

O endpoint gera uma máscara geral; a seleção Priorizar pessoa é aplicada pelo
frontend NDImages também ao resultado da API. O parâmetro person é uma indicação,
sem seleção de categoria no servidor. A raiz do servidor pode responder 503,
pois este pacote contém apenas a API, sem a compilação do site.
