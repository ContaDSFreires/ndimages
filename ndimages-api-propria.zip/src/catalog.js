const conversion = (slug, title, desc, target, input, tip, featured = false) => ({
  slug, title, desc, target, input, tip, featured, category: 'converter', icon: target === 'pdf' ? 'file-text' : 'repeat-2',
});
const tool = (slug, title, desc, category, icon, mode, tip, featured = false) => (
  { slug, title, desc, category, icon, mode, tip, featured }
);
const mockup = (product, name, desc, tip, featured = false) =>
  tool('mockup-' + product, 'Mockup de ' + name, desc, 'mockup', product.includes('caneca') ? 'coffee' : 'shirt', product, tip, featured);
export const categories = {
  converter: { label: 'Converter', color: 'blue', icon: 'repeat-2' },
  editor: { label: 'Editar', color: 'purple', icon: 'sliders-horizontal' },
  mockup: { label: 'Mockups 3D', color: 'peach', icon: 'layers' },
  print: { label: 'Impressão', color: 'green', icon: 'printer' },
  ai: { label: 'Inteligência artificial', color: 'pink', icon: 'sparkles' },
};
export const tools = [
  conversion('jpg-para-pdf', 'JPG para PDF', 'Reúna suas fotos em um PDF, na ordem que você escolher.', 'pdf', 'JPG', 'Cada foto vira uma página. Você pode mudar a ordem dos arquivos antes de gerar o PDF.', true),
  conversion('pdf-para-jpg', 'PDF para JPG', 'Salve cada página de um PDF como uma imagem JPG.', 'jpg', 'PDF', 'O JPG usa fundo branco e é útil para compartilhar páginas em aplicativos que não abrem PDF.', true),
  tool('comprimir-imagem', 'Comprimir imagem', 'Diminua o tamanho do arquivo ajustando qualidade e formato.', 'editor', 'minimize-2', 'compressor', 'Compare os tamanhos antes e depois. Qualidade menor tende a produzir arquivos menores, mas pode gerar artefatos visíveis.', true),
  tool('redimensionar-imagem', 'Redimensionar imagem', 'Ajuste as dimensões e mantenha a proporção da imagem.', 'editor', 'scaling', 'resize', 'Para redes sociais, informe as dimensões em pixels. Para papel, use a ferramenta Preparar para impressão.', true),
  mockup('caneca', 'caneca', 'Aplique sua arte em uma caneca de 11 oz com área de estampa de 20 × 9,5 cm.', 'Use uma arte de 20 × 9,5 cm para ocupar toda a área de estampa ou envie um PNG transparente para deixar a cor da caneca visível.', true),
  tool('preparar-para-impressao', 'Preparar para impressão', 'Monte arquivos em A4, tamanho de foto ou medida personalizada.', 'print', 'printer', 'print', 'A 300 DPI, uma arte de 20 × 9,5 cm precisa de aproximadamente 2.362 × 1.122 pixels. Ampliar uma imagem pequena não recria os detalhes originais.', true),
  tool('imagem-300-dpi', 'Preparar imagem a 300 DPI', 'Defina o tamanho de impressão e gere um arquivo a 300 DPI.', 'print', 'printer', 'dpi-300', 'Use as medidas da impressão para calcular os pixels necessários. Aumentar a resolução de saída não recupera detalhes da foto.'),
  tool('restaurar-foto-antiga', 'Restaurar foto antiga', 'Trate riscos, ruído e desbotamento com um modelo de restauração.', 'ai', 'sparkles', 'restore', 'Trabalhe sobre uma cópia digital. Confira rostos e detalhes no comparador: um modelo pode interpretar de forma incorreta áreas que perderam informação.', true),
  tool('remover-fundo', 'Remover fundo e objetos', 'Remova o fundo ou apague só o objeto escolhido. Baixe em PNG com transparência ou fundo colorido.', 'editor', 'scan-line', 'background-cutout', 'Use o pincel para corrigir bordas e apagar objetos que não foram reconhecidos.', true),
  conversion('converter-imagens', 'Conversor de arquivos', 'Converta imagens e documentos PDF em lote e baixe em ZIP.', 'png', '', 'Escolha JPG, PNG, WebP ou PDF na saída. BMP é aceito quando decodificável; HEIC e TIFF dependem do navegador.'),
  conversion('png-para-pdf', 'PNG para PDF', 'Combine ilustrações e capturas de tela em um documento.', 'pdf', 'PNG', 'A ordem da lista corresponde à ordem das páginas do documento final.'),
  conversion('pdf-para-png', 'PDF para PNG', 'Transforme páginas de PDF em arquivos PNG separados.', 'png', 'PDF', 'Use uma escala maior para deixar textos pequenos mais legíveis. Isso aumenta o tempo e o tamanho dos arquivos.'),
  conversion('png-para-jpg', 'PNG para JPG', 'Troque um PNG por um JPG mais fácil de compartilhar.', 'jpg', 'PNG', 'O JPG não suporta transparência. As áreas transparentes recebem fundo branco.'),
  conversion('jpg-para-png', 'JPG para PNG', 'Converta fotos JPG para PNG sem adicionar perda na exportação.', 'png', 'JPG', 'Salvar em PNG não recupera detalhes perdidos quando a foto foi salva como JPG.'),
  conversion('webp-para-jpg', 'WebP para JPG', 'Converta WebP para JPG para usar em aplicativos antigos.', 'jpg', 'WebP', 'WebP com transparência ganha fundo branco. Para conservar transparência, escolha PNG.'),
  conversion('webp-para-png', 'WebP para PNG', 'Salve imagens WebP como PNG e preserve áreas transparentes.', 'png', 'WebP', 'Em imagens animadas, a conversão exporta um quadro estático.'),
  conversion('imagem-para-webp', 'JPG ou PNG para WebP', 'Gere WebP para usar imagens mais leves na web.', 'webp', '', 'Compare o tamanho do arquivo gerado. WebP pode preservar transparência e permite ajustar qualidade.'),
  tool('extrair-imagens-pdf', 'Extrair imagens de PDF', 'Extraia as imagens incorporadas em um documento PDF.', 'converter', 'files', 'extract', 'A extração procura imagens incorporadas. Para exportar todo o conteúdo visual, incluindo texto e vetores, use PDF para PNG.'),
  tool('recortar-imagem', 'Recortar imagem', 'Selecione uma parte da imagem sem esticá-la.', 'editor', 'crop', 'crop', 'Para um avatar, use um recorte quadrado e centralize o assunto antes de exportar.'),
  tool('editar-imagem', 'Editor de imagem', 'Gire, espelhe e ajuste brilho, contraste e saturação.', 'editor', 'sliders-horizontal', 'editor', 'Brilho altera a luminosidade; contraste muda a diferença entre partes claras e escuras. Faça pequenos ajustes e confira a prévia.'),
  tool('adicionar-texto-imagem', 'Texto e marca d’água', 'Adicione uma assinatura, legenda ou marca à sua imagem.', 'editor', 'type', 'watermark', 'Uma assinatura nas bordas interfere menos no conteúdo e pode ser removida por recorte.'),
  tool('remover-metadados', 'Remover metadados EXIF', 'Exporte uma nova cópia sem os dados EXIF do original.', 'editor', 'shield-check', 'exif', 'Datas, coordenadas GPS e dados da câmera podem estar nos metadados. Informações que aparecem nos próprios pixels continuam visíveis.'),
  tool('criar-colagem', 'Montagem de Fotos', 'Monte até 16 fotos em uma grade ou em uma composição livre e exporte para impressão.', 'editor', 'layout-grid', 'composition', 'Use Ajustar para mostrar a foto inteira ou Preencher para ocupar a moldura preservando a proporção.'),
  mockup('camiseta', 'camiseta', 'Escolha o corte e o tamanho para ver sua estampa na frente ou nas costas.', 'Escolha entre Adulto, Infantil e Baby Look. As proporções e as medidas exibidas acompanham o tamanho selecionado, com tolerância de 1 cm.'),
  mockup('caneca-magica', 'caneca mágica', 'Pré-visualize uma caneca com acabamento escuro.', 'A prévia mostra a aparência da arte; o efeito térmico real depende do fornecedor e da produção.'),
  mockup('polo', 'camisa polo', 'Visualize o posicionamento da arte em uma camisa polo.', 'Teste um logotipo pequeno para conferir como ele fica em relação à gola.'),
  mockup('moletom', 'moletom', 'Veja como a estampa fica em um moletom.', 'Verifique a posição em relação ao capuz e ao bolso frontal.'),
  mockup('bone', 'boné', 'Aplique uma marca na área frontal do boné.', 'Detalhes muito finos podem se perder no bordado ou na aplicação física.'),
  mockup('almofada', 'almofada', 'Veja sua arte em uma peça decorativa.', 'Mantenha os elementos essenciais longe das bordas da estampa.'),
  mockup('quadro', 'quadro', 'Visualize sua ilustração em um quadro decorativo.', 'Ajuste o tamanho até que a moldura não cubra os elementos importantes.'),
  mockup('sacola', 'sacola', 'Monte uma prévia para sacola personalizada.', 'Centralize a marca para equilibrar visualmente a área abaixo das alças.'),
  mockup('chaveiro', 'chaveiro', 'Confira como sua arte se lê em uma peça pequena.', 'Use letras grandes e bom contraste para o tamanho final.'),
  mockup('azulejo', 'azulejo', 'Visualize padrões e estampas em um azulejo.', 'Mantenha folga nas bordas para o processo de transferência.'),
  mockup('garrafa', 'garrafa', 'Posicione sua arte sobre uma superfície cilíndrica.', 'Confira a deformação nas laterais e preserve uma área segura para texto.'),
  tool('melhorar-qualidade-imagem', 'Melhorar qualidade da imagem', 'Amplie a resolução de uma imagem com super-resolução.', 'ai', 'scan-line', 'upscale', 'Super-resolução estima detalhes. Para usos em que a exatidão é essencial, preserve também o original.'),
  tool('colorir-foto', 'Colorir foto em preto e branco', 'Gere uma interpretação em cores de uma foto antiga.', 'ai', 'palette', 'colorize', 'As cores são estimadas pelo modelo. Compare antes e depois para avaliar regiões como tons de pele e roupas.'),
];
export const legal = {
  'privacidade': {
    title: 'Política de privacidade',
    desc: 'Saiba como seus arquivos são tratados no NDImages.',
    sections: [
      ['Arquivos processados no navegador', 'Conversão, edição, impressão e mockups usam o próprio navegador. O portal não envia essas imagens ao servidor. Ao fechar a página, as prévias são descartadas. Os arquivos baixados ficam no seu dispositivo.'],
      ['Projetos de montagem', 'Ao salvar um projeto, as fotos e seus ajustes são guardados no armazenamento deste navegador. Você pode reabrir o projeto neste dispositivo enquanto os dados do site estiverem disponíveis.'],
      ['Ferramentas de inteligência artificial', 'O recorte local de fundo, o recorte aprimorado e a seleção de objetos usam seu navegador. O recorte aprimorado baixa os pesos públicos do modelo ORMBG e pode guardá-los no cache do navegador, sem enviar a foto. Ao escolher a API online e autorizar na tela, a foto é enviada ao servidor indicado, que pode ser a API própria do NDImages ou o Space público do BiRefNet no Hugging Face. O Space processa arquivos conforme suas próprias condições. Outros serviços de IA, quando disponíveis, podem enviar arquivos à Replicate mediante autorização.'],
      ['Limites de uso', 'A API pode manter, pelo dia corrente, uma contagem de solicitações por identificador derivado do endereço IP. As imagens em fila ficam apenas em memória durante a operação. O provedor da hospedagem pode manter registros técnicos de acesso.'],
      ['Preferências e publicidade', 'O site usa armazenamento local para suas preferências de aparência e privacidade. Anúncios ficam desativados até a configuração do operador e sua escolha sobre publicidade. Quando ativados, o Google e seus parceiros podem tratar dados para entregar ou medir anúncios conforme as opções apresentadas.'],
      ['Contato e direitos', 'Para solicitar informações sobre o tratamento de dados ou exercer seus direitos, use os canais de contato da DSFreires Tecnologia disponíveis no link do rodapé.'],
    ],
  },
  'termos': {
    title: 'Termos de uso',
    desc: 'Condições de uso das ferramentas do NDImages.',
    sections: [
      ['Seus arquivos', 'Envie somente imagens e documentos que você tenha autorização para usar. Você mantém os direitos sobre o conteúdo que processa.'],
      ['Resultados e cópias', 'Guarde o arquivo original. Verifique a qualidade, as cores, a proporção e as medidas do resultado antes de imprimir, publicar ou enviar para produção. Mockups representam a aparência aproximada do produto físico.'],
      ['Uso de inteligência artificial', 'Resultados de restauração, ampliação e colorização são aproximações e podem interpretar incorretamente características da foto original. Não use o resultado como prova da aparência original.'],
      ['Disponibilidade', 'A disponibilidade das ferramentas depende do navegador e, para IA, do provedor e dos limites de uso. A aplicação pode interromper operações quando o arquivo ultrapassar os limites técnicos.'],
    ],
  },
};
export const siteDescription = 'Converta, edite e prepare suas imagens para impressão. Ferramentas online gratuitas, em português e sem cadastro para tarefas simples.';
export const toolPath = tool => '/' + tool.slug + '/';
export const availableTools = (aiOperations = []) => tools.filter(tool =>
  tool.category !== 'ai' || aiOperations.includes(tool.mode));
export const legacyRoutes = { 'melhorar-qualidade-foto': 'melhorar-qualidade-imagem' };
