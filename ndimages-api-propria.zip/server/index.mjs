import { createReadStream } from 'node:fs';
import { realpath, stat } from 'node:fs/promises';
import { createServer } from 'node:http';
import { basename, extname, isAbsolute, join, relative, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { pipeline } from 'node:stream/promises';
import { createAiHandler } from './ai.mjs';
import { createBackgroundHandler } from './background.mjs';
import { legacyRoutes } from '../src/catalog.js';

const defaultDist = fileURLToPath(new URL('../dist/', import.meta.url));
const formats = new Map(Object.entries({
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.xml': 'application/xml; charset=utf-8',
  '.txt': 'text/plain; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png',
  '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.ico': 'image/x-icon',
  '.wasm': 'application/wasm', '.woff2': 'font/woff2', '.woff': 'font/woff', '.ttf': 'font/ttf',
  '.onnx': 'application/octet-stream', '.tflite': 'application/octet-stream',
  '.bcmap': 'application/octet-stream', '.pfb': 'application/octet-stream', '.icc': 'application/octet-stream',
}));

function inDist(root, target) {
  const child = relative(root, target);
  return child !== '..' && !child.startsWith(`..${sep}`) && !isAbsolute(child);
}

async function serveStatic(req, res, url, dist) {
  if (req.method !== 'GET' && req.method !== 'HEAD') {
    res.writeHead(405, { Allow: 'GET, HEAD' }).end();
    return;
  }
  const parts = decodeURIComponent(url.pathname).split('/').filter(Boolean);
  if (parts.some((part) => part.startsWith('.') || /[\\:\u0000-\u001f\u007f]/.test(part))) {
    res.writeHead(404).end();
    return;
  }
  const root = await realpath(dist).catch(() => null);
  if (!root) {
    res.writeHead(503, { 'Content-Type': 'text/plain; charset=utf-8' }).end('Execute pnpm build para preparar o site.');
    return;
  }
  const target = join(root, ...parts);
  const withIndex = extname(target) && parts.length ? target : join(target, 'index.html');
  let file = await realpath(withIndex).catch(() => null);
  if (!file || !inDist(root, file) || !formats.has(extname(file))) file = null;
  let info = file ? await stat(file).catch(() => null) : null;
  const isErrorPage = parts.length === 1 && parts[0] === '404.html';
  const found = Boolean(info?.isFile()) && !isErrorPage;
  if (found && basename(file) === 'index.html') {
    const segments = parts.at(-1) === 'index.html' ? parts.slice(0, -1) : parts;
    const legacy = segments.length === 1 && Object.hasOwn(legacyRoutes, segments[0]);
    const current = legacy ? [legacyRoutes[segments[0]]] : segments;
    const canonicalPath = current.length ? '/' + current.map(encodeURIComponent).join('/') + '/' : '/';
    if (url.pathname !== canonicalPath) {
      res.writeHead(308, { Location: canonicalPath + url.search }).end();
      return;
    }
  }
  if (!found) {
    file = await realpath(join(root, '404.html')).catch(() => null);
    info = file && inDist(root, file) ? await stat(file).catch(() => null) : null;
    if (!info?.isFile()) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }).end('Página não encontrada.');
      return;
    }
  }
  res.writeHead(found ? 200 : 404, {
    'Content-Type': formats.get(extname(file)),
    'Content-Length': info.size,
    'Cache-Control': found && parts[0] === 'assets' ? 'public, max-age=31536000, immutable' : 'no-cache',
  });
  if (req.method === 'HEAD') res.end();
  else await pipeline(createReadStream(file), res);
}

export function createPixelProntoServer({ env = process.env, dist = defaultDist, fetcher = fetch } = {}) {
  const ai = createAiHandler(env, fetcher);
  const background = createBackgroundHandler(env);
  const server = createServer({
    headersTimeout: 10_000, requestTimeout: 30_000, connectionsCheckingInterval: 1000,
  }, async (req, res) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    try {
      if (!req.url?.startsWith('/')) {
        res.writeHead(400).end();
        return;
      }
      const url = new URL(req.url, 'http://pixelpronto.local');
      if (url.pathname.startsWith('/api/background/')) await background(req, res, url);
      else if (url.pathname.startsWith('/api/')) await ai(req, res, url);
      else await serveStatic(req, res, url, dist);
    } catch (error) {
      if (res.destroyed) return;
      if (res.headersSent) {
        res.destroy();
        return;
      }
      res.writeHead(error instanceof URIError ? 400 : 500, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Não foi possível abrir este endereço.');
    }
  });
  server.once('close', background.close);
  return server;
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const port = Number(process.env.PORT || 4173);
  const host = process.env.HOST || '0.0.0.0';
  createPixelProntoServer().listen(port, host, () => {
    console.log(`NDImages disponível na porta ${port}.`);
  });
}
