import { isIP } from 'node:net';
import { setTimeout as delay } from 'node:timers/promises';

const MiB = 1024 * 1024;
const base = 'https://api.replicate.com/v1';
const operations = ['restore', 'upscale', 'colorize', 'background'];
const extensions = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp' };
const terminal = new Set(['succeeded', 'failed', 'canceled', 'aborted']);
const versionPattern = /^(?:[\w.-]+\/[\w.-]+:)?[\da-f]{64}$/i;
const providerId = /^[a-z\d_-]{1,128}$/i;
const pngSignature = Buffer.from('89504e470d0a1a0a', 'hex');

class ApiError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

function setting(env, name, fallback, min, max) {
  const n = Number(env[name]);
  return Number.isInteger(n) && n >= min && n <= max ? n : fallback;
}

function configuredModels(env) {
  const models = new Map();
  if (!env.REPLICATE_API_TOKEN?.trim() || !env.AI_MODELS_JSON) return models;
  let config;
  try {
    config = JSON.parse(env.AI_MODELS_JSON);
  } catch {
    console.error('AI_MODELS_JSON inválido. As operações de IA estão desativadas.');
    return models;
  }
  for (const operation of operations) {
    const model = config?.[operation];
    if (!model) continue;
    if (typeof model.version !== 'string' || !versionPattern.test(model.version)
      || typeof model.inputField !== 'string' || !/^[a-z][\w-]*$/i.test(model.inputField)
      || (model.input != null && (typeof model.input !== 'object' || Array.isArray(model.input)))) {
      console.error(`Configuração inválida para a operação de IA: ${operation}.`);
      continue;
    }
    models.set(operation, model);
  }
  return models;
}

function identify(buffer) {
  if (buffer.length >= 8 && buffer.subarray(0, 8).equals(pngSignature)) return 'image/png';
  if (buffer.length >= 4 && buffer[0] === 255 && buffer[1] === 216 && buffer[2] === 255) return 'image/jpeg';
  if (buffer.length >= 16 && buffer.toString('ascii', 0, 4) === 'RIFF'
    && buffer.toString('ascii', 8, 12) === 'WEBP') return 'image/webp';
  return '';
}

async function readBytes(stream, limit, status, message) {
  let length = 0;
  const chunks = [];
  for await (const chunk of stream) {
    length += chunk.length;
    if (length > limit) throw new ApiError(status, message);
    chunks.push(chunk);
  }
  return Buffer.concat(chunks, length);
}

function sendJson(res, status, data) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(data));
}

function clientIp(req, hops) {
  const socketIp = req.socket.remoteAddress || 'desconhecido';
  if (!hops || typeof req.headers['x-forwarded-for'] !== 'string') return socketIp;
  const chain = req.headers['x-forwarded-for'].split(',').map((ip) => ip.trim());
  const address = chain.at(-hops);
  return address && isIP(address) ? address : socketIp;
}

function allowOrigin(req, allowedOrigin) {
  const origin = req.headers.origin;
  if (!origin) return null;
  let parsed;
  try { parsed = new URL(origin); } catch { return false; }
  if (origin !== parsed.origin || !['https:', 'http:'].includes(parsed.protocol)) return false;
  return origin === allowedOrigin || parsed.host === req.headers.host ? origin : false;
}

function boundedQueue(concurrency, waitMs) {
  let active = 0;
  const waiting = [];

  function release() {
    const next = waiting.shift();
    if (next) next.start();
    else active--;
  }

  function acquire(signal) {
    signal.throwIfAborted();
    if (active < concurrency) {
      active++;
      return Promise.resolve(release);
    }
    return new Promise((resolve, reject) => {
      const entry = { start };
      const timer = setTimeout(() => drop(new ApiError(503, 'A fila de IA está ocupada. Tente novamente.')), waitMs);
      signal.addEventListener('abort', onAbort, { once: true });
      waiting.push(entry);

      function cleanup() {
        clearTimeout(timer);
        signal.removeEventListener('abort', onAbort);
      }
      function start() {
        cleanup();
        resolve(release);
      }
      function drop(error) {
        cleanup();
        const index = waiting.indexOf(entry);
        if (index !== -1) waiting.splice(index, 1);
        reject(error);
      }
      function onAbort() { drop(signal.reason); }
    });
  }
  return acquire;
}

function deliveryUrl(output) {
  const candidates = Array.isArray(output) ? output : [output];
  for (const candidate of candidates) {
    const value = typeof candidate === 'string' ? candidate : candidate?.url;
    let url;
    try { url = new URL(value); } catch { continue; }
    if (url.protocol === 'https:' && !url.port && !url.username && !url.password
      && (url.hostname === 'replicate.delivery' || url.hostname.endsWith('.replicate.delivery'))) return url;
  }
  throw new ApiError(502, 'O modelo não retornou uma imagem em um endereço compatível.');
}

async function replicate({ image, mime, model, signal, timeoutSeconds, outputBytes, token, fetcher, pollMs }) {
  const deadline = AbortSignal.timeout(timeoutSeconds * 1000);
  const workSignal = AbortSignal.any([signal, deadline]);
  let predictionId;
  let fileId;
  let predictionStatus;

  const request = (path, options = {}) => fetcher(`${base}${path}`, {
    signal: workSignal, ...options, redirect: 'error',
    headers: { Authorization: `Bearer ${token}`, ...options.headers },
  });
  const json = async (path, options) => {
    const response = await request(path, options);
    if (!response.ok || !response.body) {
      await response.body?.cancel().catch(() => {});
      throw new ApiError(502, 'O provedor de IA não conseguiu processar o pedido.');
    }
    return JSON.parse(await readBytes(response.body, MiB, 502, 'A resposta do provedor é grande demais.'));
  };

  try {
    let inputImage;
    if (image.length <= 256 * 1024) {
      inputImage = `data:${mime};base64,${image.toString('base64')}`;
    } else {
      const form = new FormData();
      form.append('content', new Blob([image], { type: mime }), `imagem.${extensions[mime]}`);
      form.append('metadata', new Blob(['{}'], { type: 'application/json' }));
      const file = await json('/files', { method: 'POST', body: form });
      if (typeof file.id === 'string' && providerId.test(file.id)) fileId = file.id;
      const url = new URL(file.urls?.get);
      if (!fileId || url.protocol !== 'https:' || url.username || url.password || url.port
        || (url.hostname !== 'api.replicate.com' && url.hostname !== 'replicate.delivery'
          && !url.hostname.endsWith('.replicate.delivery'))) {
        throw new ApiError(502, 'O provedor não retornou um endereço seguro para a imagem.');
      }
      inputImage = url.href;
    }

    let prediction = await json('/predictions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Cancel-After': `${timeoutSeconds}s` },
      body: JSON.stringify({ version: model.version, input: { ...model.input, [model.inputField]: inputImage } }),
    });
    if (typeof prediction.id !== 'string' || !providerId.test(prediction.id)) {
      throw new ApiError(502, 'O provedor não retornou uma identificação válida.');
    }
    predictionId = prediction.id;
    predictionStatus = prediction.status;
    while (!terminal.has(predictionStatus)) {
      await delay(pollMs, undefined, { signal: workSignal });
      prediction = await json(`/predictions/${predictionId}`);
      predictionStatus = prediction.status;
    }
    if (predictionStatus !== 'succeeded') {
      throw new ApiError(502, 'O modelo não conseguiu gerar um resultado para esta imagem.');
    }

    const response = await fetcher(deliveryUrl(prediction.output), {
      signal: workSignal, redirect: 'error',
    });
    if (!response.ok || !response.body) throw new ApiError(502, 'Não foi possível baixar o resultado da IA.');
    const contentLength = Number(response.headers.get('content-length'));
    if (contentLength > outputBytes) {
      await response.body.cancel().catch(() => {});
      throw new ApiError(502, 'A imagem gerada ultrapassou o limite de tamanho.');
    }
    const bytes = await readBytes(response.body, outputBytes, 502, 'A imagem gerada ultrapassou o limite de tamanho.');
    const type = identify(bytes);
    if (!type) throw new ApiError(502, 'O resultado do modelo não é uma imagem JPG, PNG ou WebP.');
    return { bytes, type };
  } catch (error) {
    if (deadline.aborted) throw new ApiError(504, 'A operação demorou mais que o limite. Tente uma imagem menor.');
    if (error instanceof ApiError) throw error;
    throw new ApiError(502, 'Não foi possível concluir a comunicação com o provedor de IA.');
  } finally {
    async function clean(path, method) {
      try {
        const response = await request(path, { method, signal: AbortSignal.timeout(2500) });
        await response.body?.cancel().catch(() => {});
      } catch { /* Provider expiration still applies. */ }
    }
    if (predictionId && !terminal.has(predictionStatus)) {
      await clean(`/predictions/${predictionId}/cancel`, 'POST');
    }
    if (fileId) await clean(`/files/${fileId}`, 'DELETE');
  }
}

export const configuredAiOperations = env => [...configuredModels(env).keys()];

export function createAiHandler(env = process.env, fetcher = fetch) {
  const models = configuredModels(env);
  const token = env.REPLICATE_API_TOKEN?.trim();
  const allowedOrigin = env.AI_ALLOWED_ORIGIN?.trim();
  const maxBytes = setting(env, 'AI_MAX_IMAGE_MB', 8, 1, 20) * MiB;
  const outputBytes = setting(env, 'AI_MAX_OUTPUT_MB', 20, 1, 50) * MiB;
  const concurrency = setting(env, 'AI_CONCURRENCY', 2, 1, 8);
  const waiting = setting(env, 'AI_MAX_QUEUE', 4, 0, 20);
  const timeoutSeconds = setting(env, 'AI_TIMEOUT_SECONDS', 100, 10, 240);
  const pollMs = setting(env, 'AI_POLL_MS', 1200, 200, 5000);
  const dailyPerIp = setting(env, 'AI_DAILY_PER_IP', 5, 1, 200);
  const dailyGlobal = setting(env, 'AI_DAILY_GLOBAL', 80, 1, 2000);
  const hops = setting(env, 'AI_TRUST_PROXY_HOPS', 0, 0, 5);
  const acquire = boundedQueue(concurrency, setting(env, 'AI_QUEUE_WAIT_SECONDS', 25, 2, 120) * 1000);
  let inflight = 0;
  let day;
  let dailyTotal = 0;
  const perIp = new Map();

  function quota(ip, reserve = false) {
    const today = new Date().toISOString().slice(0, 10);
    if (day !== today) {
      day = today;
      dailyTotal = 0;
      perIp.clear();
    }
    const count = perIp.get(ip) || 0;
    if (count >= dailyPerIp || dailyTotal >= dailyGlobal) {
      throw new ApiError(429, 'O limite diário de IA foi atingido. Tente novamente amanhã.');
    }
    if (reserve) {
      dailyTotal++;
      perIp.set(ip, count + 1);
    }
  }

  return async function handleAi(req, res, url) {
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('Vary', 'Origin');
    const origin = allowOrigin(req, allowedOrigin);
    if (origin === false) return sendJson(res, 403, { error: 'Origem não permitida.' });
    if (origin) res.setHeader('Access-Control-Allow-Origin', origin);
    const status = url.pathname === '/api/ai/status';
    const process = url.pathname === '/api/ai/process';
    if (!status && !process) return sendJson(res, 404, { error: 'Rota não encontrada.' });
    if (req.method === 'OPTIONS') {
      res.writeHead(204, {
        'Access-Control-Allow-Methods': status ? 'GET, OPTIONS' : 'POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Max-Age': '600',
      }).end();
      return;
    }
    if (status && req.method === 'GET') return sendJson(res, 200, { operations: [...models.keys()], maxBytes });
    if (status || req.method !== 'POST') {
      res.setHeader('Allow', status ? 'GET, OPTIONS' : 'POST, OPTIONS');
      return sendJson(res, 405, { error: 'Método não permitido.' });
    }

    const controller = new AbortController();
    res.once('close', () => {
      if (!res.writableFinished) controller.abort();
    });
    let release;
    let admitted = false;
    try {
      const operation = url.searchParams.get('operation');
      if (!operations.includes(operation)) throw new ApiError(400, 'Escolha uma operação de IA válida.');
      const model = models.get(operation);
      if (!model) throw new ApiError(503, 'Esta operação de IA ainda não foi ativada.');
      const mime = req.headers['content-type']?.split(';')[0].trim().toLowerCase();
      if (!extensions[mime]) throw new ApiError(415, 'Envie uma imagem JPG, PNG ou WebP.');
      const tooLarge = `A imagem ultrapassa ${maxBytes / MiB} MB.`;
      if (Number(req.headers['content-length']) > maxBytes) throw new ApiError(413, tooLarge);
      const ip = clientIp(req, hops);
      quota(ip);
      if (inflight >= concurrency + waiting) {
        throw new ApiError(503, 'A fila de IA está cheia. Tente novamente em instantes.');
      }
      inflight++;
      admitted = true;
      const image = await readBytes(req.iterator({ destroyOnReturn: false }), maxBytes, 413, tooLarge);
      if (identify(image) !== mime) throw new ApiError(415, 'O conteúdo do arquivo não corresponde ao formato informado.');
      release = await acquire(controller.signal);
      quota(ip, true);
      const { bytes, type } = await replicate({
        image, mime, model, signal: controller.signal, timeoutSeconds, outputBytes, token, fetcher, pollMs,
      });
      if (!res.destroyed) res.writeHead(200, { 'Content-Type': type, 'Content-Length': bytes.length }).end(bytes);
    } catch (error) {
      if (res.destroyed) return;
      if (!req.complete) res.setHeader('Connection', 'close');
      const status = error instanceof ApiError ? error.status : 500;
      if (status === 429) {
        const now = new Date();
        const midnight = Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() + 1);
        res.setHeader('Retry-After', String(Math.ceil((midnight - now.getTime()) / 1000)));
      }
      sendJson(res, status, { error: error instanceof ApiError ? error.message : 'Não foi possível processar a imagem.' });
    } finally {
      release?.();
      if (admitted) inflight--;
    }
  };
}
