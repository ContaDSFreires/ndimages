import { access } from 'node:fs/promises';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { Worker } from 'node:worker_threads';

const defaultModel = fileURLToPath(new URL('../public/models/u2netp.onnx', import.meta.url));
const maxBytes = 16 * 1024 * 1024;
const types = new Set(['image/png', 'image/jpeg', 'image/webp']);
function imageType(bytes) {
  if (bytes.length >= 8 && bytes.subarray(0, 8).equals(Buffer.from('89504e470d0a1a0a', 'hex'))) return 'image/png';
  if (bytes.length >= 3 && bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255) return 'image/jpeg';
  if (bytes.length >= 12 && bytes.toString('ascii', 0, 4) === 'RIFF' && bytes.toString('ascii', 8, 12) === 'WEBP') return 'image/webp';
  return '';
}

export function createBackgroundHandler(env = process.env) {
  const enabled = env.NDIMAGES_BG_ENABLED === 'true';
  const kind = env.NDIMAGES_BG_MODEL_KIND === 'ormbg' ? 'ormbg' : 'u2netp';
  const modelPath = env.NDIMAGES_BG_MODEL ? resolve(env.NDIMAGES_BG_MODEL) : defaultModel;
  const allowedOrigin = (env.NDIMAGES_BG_ALLOWED_ORIGIN || env.AI_ALLOWED_ORIGIN || env.SITE_URL || '').trim();
  const perHour = Math.max(1, Math.min(1000, Number(env.NDIMAGES_BG_REQUESTS_PER_HOUR) || 30));
  let worker;
  let active;
  let nextId = 0;
  let hour = 0;
  const requests = new Map();

  function stopWorker() {
    const previous = worker;
    worker = undefined;
    previous?.terminate();
  }

  async function run(image, signal) {
    const current = worker ??= new Worker(new URL('./background-engine.mjs', import.meta.url), { workerData: { kind, modelPath } });
    const id = ++nextId;
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => fail(new Error('O processamento excedeu três minutos.')), 180_000);
      function cleanup() {
        clearTimeout(timeout);
        signal.removeEventListener('abort', abort);
        current.off('message', message);
        current.off('error', fail);
        current.off('exit', exited);
      }
      function fail(error) { cleanup(); stopWorker(); reject(error); }
      function abort() { fail(new Error('Processamento cancelado.')); }
      function exited() { fail(new Error('O processamento foi interrompido.')); }
      function message(result) {
        if (result.id !== id) return;
        cleanup();
        if (result.error) reject(new Error(result.error));
        else resolve(result.png);
      }
      current.on('message', message);
      current.once('error', fail);
      current.once('exit', exited);
      signal.addEventListener('abort', abort, { once: true });
      if (signal.aborted) abort();
      else current.postMessage({ id, image });
    });
  }

  function json(res, status, error) {
    res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
    res.end(JSON.stringify(typeof error === 'string' ? { error } : error));
  }

  const handler = async (req, res, url) => {
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('Vary', 'Origin');
    const origin = req.headers.origin;
    const sameOrigin = origin === 'https://' + req.headers.host || origin === 'http://' + req.headers.host;
    if (origin && origin !== allowedOrigin && !sameOrigin) return json(res, 403, 'Origem não permitida.');
    if (origin) res.setHeader('Access-Control-Allow-Origin', origin);
    const status = url.pathname === '/api/background/status';
    const remove = url.pathname === '/api/background/remove';
    if (!status && !remove) return json(res, 404, 'Rota não encontrada.');
    if (req.method === 'OPTIONS') {
      res.writeHead(204, { 'Access-Control-Allow-Methods': status ? 'GET, OPTIONS' : 'POST, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type' }).end();
      return;
    }
    const ready = enabled && await access(modelPath).then(() => true, () => false);
    if (status && req.method === 'GET') return json(res, 200, { available: ready, provider: 'ndimages-local', model: kind, maxBytes });
    if (status || req.method !== 'POST') return json(res, 405, 'Método não permitido.');
    if (!ready) return json(res, 503, 'A API própria de recorte ainda não foi ativada neste servidor.');
    const mime = req.headers['content-type']?.split(';')[0]?.trim().toLowerCase();
    if (!types.has(mime)) return json(res, 415, 'Envie uma imagem JPG, PNG ou WebP.');
    if (Number(req.headers['content-length']) > maxBytes) return json(res, 413, 'A imagem ultrapassa 16 MB.');
    if (active) return json(res, 503, 'O servidor está processando outra imagem. Tente novamente em instantes.');
    const now = Math.floor(Date.now() / 3_600_000);
    if (now !== hour) { hour = now; requests.clear(); }
    const ip = req.socket.remoteAddress || 'unknown';
    const count = requests.get(ip) || 0;
    if (count >= perHour) return json(res, 429, 'O limite de recortes desta hora foi atingido.');
    if (requests.size > 10_000 && !requests.has(ip)) return json(res, 503, 'O servidor está ocupado.');
    const controller = new AbortController();
    active = controller;
    res.once('close', () => { if (!res.writableFinished) controller.abort(); });
    try {
      const chunks = [];
      let length = 0;
      for await (const chunk of req.iterator({ destroyOnReturn: false })) {
        length += chunk.length;
        if (length > maxBytes) { res.setHeader('Connection', 'close'); return json(res, 413, 'A imagem ultrapassa 16 MB.'); }
        chunks.push(chunk);
      }
      if (!length) return json(res, 400, 'A imagem está vazia.');
      const image = Buffer.concat(chunks, length);
      if (imageType(image) !== mime) return json(res, 415, 'O arquivo não corresponde ao formato informado.');
      requests.set(ip, count + 1);
      const png = await run(image, controller.signal);
      if (res.destroyed) return;
      if (png.length > 24 * 1024 * 1024) return json(res, 413, 'O recorte ultrapassa o limite de saída de 24 MB.');
      res.writeHead(200, { 'Content-Type': 'image/png', 'Content-Length': png.length }).end(png);
    } catch {
      if (!res.destroyed) json(res, 422, 'Não foi possível processar esta imagem na API própria.');
    } finally { if (active === controller) active = undefined; }
  };
  handler.close = () => { active?.abort(); stopWorker(); };
  return handler;
}
