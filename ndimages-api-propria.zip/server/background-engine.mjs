import { parentPort, workerData } from 'node:worker_threads';
import { readFile } from 'node:fs/promises';
import sharp from 'sharp';
import * as ort from 'onnxruntime-web/wasm';

ort.env.wasm.numThreads = 1;
const kind = workerData.kind;
const side = kind === 'ormbg' ? 1024 : 320;
const plane = side * side;
let session;

async function removeBackground(bytes) {
  const photo = await sharp(bytes, { limitInputPixels: 16_000_000 }).rotate().ensureAlpha().raw().toBuffer({ resolveWithObject: true });
  const { width, height } = photo.info;
  if (Math.max(width, height) > 8192) throw new Error('A imagem ultrapassa o limite de 8.192 pixels por lado.');
  const reduced = await sharp(photo.data, { raw: { width, height, channels: 4 } })
    .flatten({ background: '#fff' }).removeAlpha().resize(side, side, { fit: 'fill' }).raw().toBuffer();
  const inputValues = new Float32Array(3 * plane);
  const mean = [0.485, 0.456, 0.406];
  const deviation = [0.229, 0.224, 0.225];
  let maximum = 255;
  if (kind === 'u2netp') {
    maximum = 1;
    for (const value of reduced) maximum = Math.max(maximum, value);
  }
  for (let channel = 0; channel < 3; channel++) {
    for (let pixel = 0; pixel < plane; pixel++) {
      const value = reduced[3 * pixel + channel] / maximum;
      inputValues[channel * plane + pixel] = kind === 'u2netp' ? (value - mean[channel]) / deviation[channel] : value;
    }
  }
  session ??= await ort.InferenceSession.create(await readFile(workerData.modelPath), { executionProviders: ['wasm'] });
  const input = new ort.Tensor('float32', inputValues, [1, 3, side, side]);
  let output;
  try {
    output = (await session.run({ [session.inputNames[0]]: input }, [session.outputNames[0]]))[session.outputNames[0]];
    if (output.data.length !== plane) throw new Error('O modelo retornou uma máscara incompatível.');
    let low = kind === 'ormbg' ? 0 : Infinity;
    let high = kind === 'ormbg' ? 1 : -Infinity;
    for (const value of output.data) {
      if (!Number.isFinite(value)) throw new Error('O modelo retornou uma máscara inválida.');
      if (kind === 'u2netp') { low = Math.min(low, value); high = Math.max(high, value); }
    }
    const alpha = new Uint8Array(plane);
    const scale = high - low > 1e-6 ? 255 / (high - low) : 0;
    for (let i = 0; i < plane; i++) alpha[i] = Math.round(Math.max(0, Math.min(255, (output.data[i] - low) * scale)));
    const mask = await sharp(alpha, { raw: { width: side, height: side, channels: 1 } })
      .resize(width, height, { fit: 'fill' }).greyscale().raw().toBuffer();
    if (mask.length !== width * height) throw new Error('O tamanho do recorte é inválido.');
    for (let i = 0; i < mask.length; i++) photo.data[i * 4 + 3] = Math.round(photo.data[i * 4 + 3] * mask[i] / 255);
    return sharp(photo.data, { raw: { width, height, channels: 4 } }).png().toBuffer();
  } finally {
    input.dispose();
    output?.dispose();
  }
}

parentPort.on('message', async ({ id, image }) => {
  try { parentPort.postMessage({ id, png: await removeBackground(image) }); }
  catch (error) { parentPort.postMessage({ id, error: error.message }); }
});
