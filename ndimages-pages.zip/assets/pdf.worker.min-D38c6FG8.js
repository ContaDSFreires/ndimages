const s="/ndimages/assets/pdf.worker.min-iDqQPrd3.mjs";export{s as default};
